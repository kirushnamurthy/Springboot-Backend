package com.example.project_BackEnd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectBackEndApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectBackEndApplication.class, args);
	}

}
